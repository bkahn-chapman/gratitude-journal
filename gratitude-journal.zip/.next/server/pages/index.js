"use strict";
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/Greeting.js":
/*!********************************!*\
  !*** ./components/Greeting.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Greeting)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\components\\Greeting.js";

function Greeting({
  user,
  color,
  gratitudes,
  hasSubmittedToday
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "text-white text-6xl",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
      children: ["Hello, ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: color,
        children: user.email
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 5,
        columnNumber: 24
      }, this), "!"]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 4,
      columnNumber: 13
    }, this), hasSubmittedToday ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
      className: "font-bold",
      children: ["Today you're grateful for ", gratitudes.slice(-1)[0], "."]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 21
    }, this) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
      className: "font-bold mt-4",
      children: "What are you grateful for today?"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 21
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./components/History.js":
/*!*******************************!*\
  !*** ./components/History.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ History)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\components\\History.js";

function History({
  gratitudes
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
    className: "text-white text-2xl mt-1",
    children: ["Previously, you were grateful for", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
      className: "font-bold",
      children: gratitudes.map(g => ' ' + g).toString()
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 4,
      columnNumber: 13
    }, this), "."]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./components/Input.js":
/*!*****************************!*\
  !*** ./components/Input.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\components\\Input.js";


function Input({
  handleSubmit
}) {
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");

  let submitForm = e => {
    e.preventDefault();
    handleSubmit(value);
    setValue("");
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("form", {
    onSubmit: submitForm,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("input", {
      placeholder: "Enter gratitude here.",
      type: "text",
      value: value,
      onChange: e => setValue(e.target.value),
      className: "rounded px-3 py-2 mr-6 mt-8"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("button", {
      type: "submit",
      className: "bg-green-400 rounded px-12 py-2 font-medium",
      children: "Save"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Greeting__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Greeting */ "./components/Greeting.js");
/* harmony import */ var _components_History__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/History */ "./components/History.js");
/* harmony import */ var _components_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Input */ "./components/Input.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\pages\\index.js";







function Home() {
  const {
    0: user,
    1: setUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
    "name": "Ben",
    "email": "bkahn@chapman.edu"
  });
  const {
    0: gratitudes,
    1: setGratitudes
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(['hockey', 'computers']);
  const {
    0: hasSubmittedToday,
    1: setSubmittedToday
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);

  const addGratitude = entry => {
    let newGratitudes = [...gratitudes, entry];
    setGratitudes(newGratitudes);
    setSubmittedToday(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
    className: "jsx-3938730314" + " " + "bg-blue-900 min-h-screen min-w-screen",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("title", {
        className: "jsx-3938730314",
        children: "Hello"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico",
        className: "jsx-3938730314"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("main", {
      className: "jsx-3938730314" + " " + "red container mx-auto max-w-prose px-4 pt-12",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Greeting__WEBPACK_IMPORTED_MODULE_2__.default, {
        color: "text-green-400",
        user: user,
        gratitudes: gratitudes,
        hasSubmittedToday: hasSubmittedToday
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this), !hasSubmittedToday && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Input__WEBPACK_IMPORTED_MODULE_4__.default, {
        handleSubmit: addGratitude
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 33
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, this), gratitudes.length > 0 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_History__WEBPACK_IMPORTED_MODULE_3__.default, {
        gratitudes: gratitudes
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default()), {
      id: "3938730314",
      children: ".spacer.jsx-3938730314{height:20px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBNkNrQixBQUd1QixZQUNkIiwiZmlsZSI6IkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoWydob2NrZXknLCAnY29tcHV0ZXJzJ10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS05MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVkIGNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTJcIj5cbiAgICAgICAgPEdyZWV0aW5nXG4gICAgICAgICAgY29sb3I9XCJ0ZXh0LWdyZWVuLTQwMFwiXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBncmF0aXR1ZGVzPXtncmF0aXR1ZGVzfVxuICAgICAgICAgIGhhc1N1Ym1pdHRlZFRvZGF5PXtoYXNTdWJtaXR0ZWRUb2RheX1cbiAgICAgICAgPjwvR3JlZXRpbmc+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2VyXCIgLz5cbiAgICAgICAge1xuICAgICAgICAgICFoYXNTdWJtaXR0ZWRUb2RheSAmJiA8SW5wdXQgaGFuZGxlU3VibWl0PXthZGRHcmF0aXR1ZGV9IC8+XG4gICAgICAgIH1cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgZ3JhdGl0dWRlcy5sZW5ndGggPiAwICYmIFxuICAgICAgICAgIDxIaXN0b3J5IGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9IC8+XG4gICAgICAgIH1cbiAgICAgIDwvbWFpbj5cbiAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgLnNwYWNlciB7XG4gICAgICAgICAgaGVpZ2h0OiAyMHB4O1xuICAgICAgICB9XG4gICAgICBgfTwvc3R5bGU+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ== */\n/*@ sourceURL=C:\\\\Users\\\\Benjamin\\\\Desktop\\\\CPSC458\\\\gratitude-journal\\\\pages\\\\index.js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQWUsU0FBU0EsUUFBVCxDQUFrQjtBQUFDQyxFQUFBQSxJQUFEO0FBQU9DLEVBQUFBLEtBQVA7QUFBY0MsRUFBQUEsVUFBZDtBQUEwQkMsRUFBQUE7QUFBMUIsQ0FBbEIsRUFBZ0U7QUFDM0Usc0JBQ0k7QUFBSyxhQUFTLEVBQUMscUJBQWY7QUFBQSw0QkFDSTtBQUFBLHlDQUNXO0FBQU0saUJBQVMsRUFBRUYsS0FBakI7QUFBQSxrQkFBeUJELElBQUksQ0FBQ0k7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLEVBS1FELGlCQUFpQixnQkFDYjtBQUFJLGVBQVMsRUFBQyxXQUFkO0FBQUEsK0NBQXFERCxVQUFVLENBQUNHLEtBQVgsQ0FBaUIsQ0FBQyxDQUFsQixFQUFxQixDQUFyQixDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFEYSxnQkFHYjtBQUFJLGVBQVMsRUFBQyxnQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURKO0FBY0g7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZjLFNBQVNDLE9BQVQsQ0FBaUI7QUFBRUosRUFBQUE7QUFBRixDQUFqQixFQUFpQztBQUM1QyxzQkFDSTtBQUFHLGFBQVMsRUFBQywwQkFBYjtBQUFBLGlFQUNJO0FBQU0sZUFBUyxFQUFDLFdBQWhCO0FBQUEsZ0JBQ0tBLFVBQVUsQ0FBQ0ssR0FBWCxDQUFlQyxDQUFDLElBQUksTUFBSUEsQ0FBeEIsRUFBMkJDLFFBQTNCO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURKO0FBUUg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNURDs7QUFDZSxTQUFTRSxLQUFULENBQWU7QUFBQ0MsRUFBQUE7QUFBRCxDQUFmLEVBQStCO0FBQzFDLFFBQU07QUFBQSxPQUFDQyxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQkosK0NBQVEsQ0FBQyxFQUFELENBQWxDOztBQUVBLE1BQUlLLFVBQVUsR0FBR0MsQ0FBQyxJQUFJO0FBQ2xCQSxJQUFBQSxDQUFDLENBQUNDLGNBQUY7QUFDQUwsSUFBQUEsWUFBWSxDQUFDQyxLQUFELENBQVo7QUFDQUMsSUFBQUEsUUFBUSxDQUFDLEVBQUQsQ0FBUjtBQUNILEdBSkQ7O0FBTUEsc0JBQ0k7QUFBTSxZQUFRLEVBQUVDLFVBQWhCO0FBQUEsNEJBQ0k7QUFBTyxpQkFBVyxFQUFDLHVCQUFuQjtBQUEyQyxVQUFJLEVBQUMsTUFBaEQ7QUFBdUQsV0FBSyxFQUFFRixLQUE5RDtBQUNJLGNBQVEsRUFBRUcsQ0FBQyxJQUFJRixRQUFRLENBQUNFLENBQUMsQ0FBQ0UsTUFBRixDQUFTTCxLQUFWLENBRDNCO0FBRUksZUFBUyxFQUFDO0FBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLGVBS0k7QUFBUSxVQUFJLEVBQUMsUUFBYjtBQUFzQixlQUFTLEVBQUMsNkNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREo7QUFTSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUsU0FBU08sSUFBVCxHQUFnQjtBQUM3QixRQUFNO0FBQUEsT0FBQ3BCLElBQUQ7QUFBQSxPQUFPcUI7QUFBUCxNQUFrQlgsK0NBQVEsQ0FBQztBQUM3QixZQUFRLEtBRHFCO0FBRTdCLGFBQVM7QUFGb0IsR0FBRCxDQUFoQztBQUtBLFFBQU07QUFBQSxPQUFDUixVQUFEO0FBQUEsT0FBYW9CO0FBQWIsTUFBOEJaLCtDQUFRLENBQUMsQ0FBQyxRQUFELEVBQVcsV0FBWCxDQUFELENBQTVDO0FBQ0EsUUFBTTtBQUFBLE9BQUNQLGlCQUFEO0FBQUEsT0FBb0JvQjtBQUFwQixNQUF5Q2IsK0NBQVEsQ0FBQyxLQUFELENBQXZEOztBQUVBLFFBQU1jLFlBQVksR0FBSUMsS0FBRCxJQUFXO0FBQzlCLFFBQUlDLGFBQWEsR0FBRyxDQUFDLEdBQUd4QixVQUFKLEVBQWdCdUIsS0FBaEIsQ0FBcEI7QUFDQUgsSUFBQUEsYUFBYSxDQUFDSSxhQUFELENBQWI7QUFDQUgsSUFBQUEsaUJBQWlCLENBQUMsSUFBRCxDQUFqQjtBQUNELEdBSkQ7O0FBTUEsc0JBQ0U7QUFBQSx3Q0FBZSx1Q0FBZjtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUMsY0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQU1FO0FBQUEsMENBQWdCLDhDQUFoQjtBQUFBLDhCQUNFLDhEQUFDLHlEQUFEO0FBQ0UsYUFBSyxFQUFDLGdCQURSO0FBRUUsWUFBSSxFQUFFdkIsSUFGUjtBQUdFLGtCQUFVLEVBQUVFLFVBSGQ7QUFJRSx5QkFBaUIsRUFBRUM7QUFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBT0U7QUFBQSw0Q0FBZTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRixFQVNJLENBQUNBLGlCQUFELGlCQUFzQiw4REFBQyxzREFBRDtBQUFPLG9CQUFZLEVBQUVxQjtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVDFCLGVBV0U7QUFBQSw0Q0FBZTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FYRixFQWFJdEIsVUFBVSxDQUFDeUIsTUFBWCxHQUFvQixDQUFwQixpQkFDQSw4REFBQyx3REFBRDtBQUFTLGtCQUFVLEVBQUV6QjtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUErQkQ7Ozs7Ozs7Ozs7QUNwREQ7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0dyZWV0aW5nLmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvSGlzdG9yeS5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0lucHV0LmpzIiwid2VicGFjazovLy8uL3BhZ2VzL2luZGV4LmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic3R5bGVkLWpzeC9zdHlsZVwiIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyZWV0aW5nKHt1c2VyLCBjb2xvciwgZ3JhdGl0dWRlcywgaGFzU3VibWl0dGVkVG9kYXl9KSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTZ4bFwiPlxyXG4gICAgICAgICAgICA8aDE+XHJcbiAgICAgICAgICAgICAgICBIZWxsbywgPHNwYW4gY2xhc3NOYW1lPXtjb2xvcn0+e3VzZXIuZW1haWx9PC9zcGFuPiFcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGFzU3VibWl0dGVkVG9kYXkgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlRvZGF5IHlvdSdyZSBncmF0ZWZ1bCBmb3Ige2dyYXRpdHVkZXMuc2xpY2UoLTEpWzBdfS48L2gyPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1ib2xkIG10LTRcIj5XaGF0IGFyZSB5b3UgZ3JhdGVmdWwgZm9yIHRvZGF5PzwvaDI+XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIaXN0b3J5KHsgZ3JhdGl0dWRlcyB9KSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC0yeGwgbXQtMVwiPlByZXZpb3VzbHksIHlvdSB3ZXJlIGdyYXRlZnVsIGZvclxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj4gXHJcbiAgICAgICAgICAgICAgICB7Z3JhdGl0dWRlcy5tYXAoZyA9PiAnICcrZykudG9TdHJpbmcoKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgKVxyXG59IiwiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW5wdXQoe2hhbmRsZVN1Ym1pdH0pIHtcclxuICAgIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoXCJcIilcclxuXHJcbiAgICBsZXQgc3VibWl0Rm9ybSA9IGUgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgIGhhbmRsZVN1Ym1pdCh2YWx1ZSlcclxuICAgICAgICBzZXRWYWx1ZShcIlwiKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3N1Ym1pdEZvcm19PlxyXG4gICAgICAgICAgICA8aW5wdXQgcGxhY2Vob2xkZXI9XCJFbnRlciBncmF0aXR1ZGUgaGVyZS5cIiB0eXBlPVwidGV4dFwiIHZhbHVlPXt2YWx1ZX0gXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRWYWx1ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHB4LTMgcHktMiBtci02IG10LThcIj5cclxuICAgICAgICAgICAgPC9pbnB1dD5cclxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNDAwIHJvdW5kZWQgcHgtMTIgcHktMiBmb250LW1lZGl1bVwiPlNhdmU8L2J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICApXHJcbn0iLCJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoWydob2NrZXknLCAnY29tcHV0ZXJzJ10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS05MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVkIGNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTJcIj5cbiAgICAgICAgPEdyZWV0aW5nXG4gICAgICAgICAgY29sb3I9XCJ0ZXh0LWdyZWVuLTQwMFwiXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBncmF0aXR1ZGVzPXtncmF0aXR1ZGVzfVxuICAgICAgICAgIGhhc1N1Ym1pdHRlZFRvZGF5PXtoYXNTdWJtaXR0ZWRUb2RheX1cbiAgICAgICAgPjwvR3JlZXRpbmc+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2VyXCIgLz5cbiAgICAgICAge1xuICAgICAgICAgICFoYXNTdWJtaXR0ZWRUb2RheSAmJiA8SW5wdXQgaGFuZGxlU3VibWl0PXthZGRHcmF0aXR1ZGV9IC8+XG4gICAgICAgIH1cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgZ3JhdGl0dWRlcy5sZW5ndGggPiAwICYmIFxuICAgICAgICAgIDxIaXN0b3J5IGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9IC8+XG4gICAgICAgIH1cbiAgICAgIDwvbWFpbj5cbiAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgLnNwYWNlciB7XG4gICAgICAgICAgaGVpZ2h0OiAyMHB4O1xuICAgICAgICB9XG4gICAgICBgfTwvc3R5bGU+XG4gICAgPC9kaXY+XG4gIClcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWpzeC9zdHlsZVwiKTsiXSwibmFtZXMiOlsiR3JlZXRpbmciLCJ1c2VyIiwiY29sb3IiLCJncmF0aXR1ZGVzIiwiaGFzU3VibWl0dGVkVG9kYXkiLCJlbWFpbCIsInNsaWNlIiwiSGlzdG9yeSIsIm1hcCIsImciLCJ0b1N0cmluZyIsInVzZVN0YXRlIiwiSW5wdXQiLCJoYW5kbGVTdWJtaXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwic3VibWl0Rm9ybSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsIkhlYWQiLCJIb21lIiwic2V0VXNlciIsInNldEdyYXRpdHVkZXMiLCJzZXRTdWJtaXR0ZWRUb2RheSIsImFkZEdyYXRpdHVkZSIsImVudHJ5IiwibmV3R3JhdGl0dWRlcyIsImxlbmd0aCJdLCJzb3VyY2VSb290IjoiIn0=