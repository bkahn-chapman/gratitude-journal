"use strict";
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/Greeting.js":
/*!********************************!*\
  !*** ./components/Greeting.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Greeting)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\components\\Greeting.js";

function Greeting({
  user,
  color,
  gratitudes,
  hasSubmittedToday
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "text-white text-6xl",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
      children: ["Hello, ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: color,
        children: user.email
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 5,
        columnNumber: 24
      }, this), "!"]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 4,
      columnNumber: 13
    }, this), hasSubmittedToday ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
      className: "font-black",
      children: ["Today you're grateful for ", gratitudes.slice(-1)[0], "."]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 21
    }, this) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
      className: "font-black",
      children: "What are you grateful for today?"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 21
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./components/History.js":
/*!*******************************!*\
  !*** ./components/History.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ History)
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\components\\History.js";

function History({
  gratitudes
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
    className: "text-white text-2xl",
    children: ["Previously, you were grateful for", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
      className: "font-bold",
      children: gratitudes.map(g => ' ' + g).toString()
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 4,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 3,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./components/Input.js":
/*!*****************************!*\
  !*** ./components/Input.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\components\\Input.js";


function Input({
  handleSubmit
}) {
  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");

  let submitForm = e => {
    e.preventDefault();
    handleSubmit(value);
    setValue("");
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("form", {
    onSubmit: submitForm,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("input", {
      placeholder: "Enter gratitude here.",
      type: "text",
      value: value,
      onChange: e => setValue(e.target.value),
      className: "rounded px-3 py-2"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("button", {
      type: "submit",
      className: "bg-pink-300 rounded px-12 py-2",
      children: "Save"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 9
  }, this);
}

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Greeting__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Greeting */ "./components/Greeting.js");
/* harmony import */ var _components_History__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/History */ "./components/History.js");
/* harmony import */ var _components_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Input */ "./components/Input.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\pages\\index.js";







function Home() {
  const {
    0: user,
    1: setUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
    "name": "Ben",
    "email": "bkahn@chapman.edu"
  });
  const {
    0: gratitudes,
    1: setGratitudes
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(['hockey', 'computers']);
  const {
    0: hasSubmittedToday,
    1: setSubmittedToday
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);

  const addGratitude = entry => {
    let newGratitudes = [...gratitudes, entry];
    setGratitudes(newGratitudes);
    setSubmittedToday(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
    className: "jsx-3938730314" + " " + "bg-gray-700 min-h-screen min-w-screen",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("title", {
        className: "jsx-3938730314",
        children: "Hello"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico",
        className: "jsx-3938730314"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("main", {
      className: "jsx-3938730314" + " " + "red container mx-auto max-w-prose px-4 pt-12",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Greeting__WEBPACK_IMPORTED_MODULE_2__.default, {
        color: "text-pink-300",
        user: user,
        gratitudes: gratitudes,
        hasSubmittedToday: hasSubmittedToday
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this), !hasSubmittedToday && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Input__WEBPACK_IMPORTED_MODULE_4__.default, {
        handleSubmit: addGratitude
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 33
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, this), gratitudes.length > 0 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_History__WEBPACK_IMPORTED_MODULE_3__.default, {
        gratitudes: gratitudes
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default()), {
      id: "3938730314",
      children: ".spacer.jsx-3938730314{height:20px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBNkNrQixBQUd1QixZQUNkIiwiZmlsZSI6IkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoWydob2NrZXknLCAnY29tcHV0ZXJzJ10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS03MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVkIGNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTJcIj5cbiAgICAgICAgPEdyZWV0aW5nXG4gICAgICAgICAgY29sb3I9XCJ0ZXh0LXBpbmstMzAwXCJcbiAgICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICAgIGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9XG4gICAgICAgICAgaGFzU3VibWl0dGVkVG9kYXk9e2hhc1N1Ym1pdHRlZFRvZGF5fVxuICAgICAgICA+PC9HcmVldGluZz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgIWhhc1N1Ym1pdHRlZFRvZGF5ICYmIDxJbnB1dCBoYW5kbGVTdWJtaXQ9e2FkZEdyYXRpdHVkZX0gLz5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlclwiIC8+XG4gICAgICAgIHtcbiAgICAgICAgICBncmF0aXR1ZGVzLmxlbmd0aCA+IDAgJiYgXG4gICAgICAgICAgPEhpc3RvcnkgZ3JhdGl0dWRlcz17Z3JhdGl0dWRlc30gLz5cbiAgICAgICAgfVxuICAgICAgPC9tYWluPlxuICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAuc3BhY2VyIHtcbiAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgIH1cbiAgICAgIGB9PC9zdHlsZT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Benjamin\\\\Desktop\\\\CPSC458\\\\gratitude-journal\\\\pages\\\\index.js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQWUsU0FBU0EsUUFBVCxDQUFrQjtBQUFDQyxFQUFBQSxJQUFEO0FBQU9DLEVBQUFBLEtBQVA7QUFBY0MsRUFBQUEsVUFBZDtBQUEwQkMsRUFBQUE7QUFBMUIsQ0FBbEIsRUFBZ0U7QUFDM0Usc0JBQ0k7QUFBSyxhQUFTLEVBQUMscUJBQWY7QUFBQSw0QkFDSTtBQUFBLHlDQUNXO0FBQU0saUJBQVMsRUFBRUYsS0FBakI7QUFBQSxrQkFBeUJELElBQUksQ0FBQ0k7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLEVBS1FELGlCQUFpQixnQkFDYjtBQUFJLGVBQVMsRUFBQyxZQUFkO0FBQUEsK0NBQXNERCxVQUFVLENBQUNHLEtBQVgsQ0FBaUIsQ0FBQyxDQUFsQixFQUFxQixDQUFyQixDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFEYSxnQkFHYjtBQUFJLGVBQVMsRUFBQyxZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREo7QUFjSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZmMsU0FBU0MsT0FBVCxDQUFpQjtBQUFFSixFQUFBQTtBQUFGLENBQWpCLEVBQWlDO0FBQzVDLHNCQUNJO0FBQUcsYUFBUyxFQUFDLHFCQUFiO0FBQUEsaUVBQ0k7QUFBTSxlQUFTLEVBQUMsV0FBaEI7QUFBQSxnQkFDS0EsVUFBVSxDQUFDSyxHQUFYLENBQWVDLENBQUMsSUFBSSxNQUFJQSxDQUF4QixFQUEyQkMsUUFBM0I7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREo7QUFPSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JEOztBQUNlLFNBQVNFLEtBQVQsQ0FBZTtBQUFDQyxFQUFBQTtBQUFELENBQWYsRUFBK0I7QUFDMUMsUUFBTTtBQUFBLE9BQUNDLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CSiwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7O0FBRUEsTUFBSUssVUFBVSxHQUFHQyxDQUFDLElBQUk7QUFDbEJBLElBQUFBLENBQUMsQ0FBQ0MsY0FBRjtBQUNBTCxJQUFBQSxZQUFZLENBQUNDLEtBQUQsQ0FBWjtBQUNBQyxJQUFBQSxRQUFRLENBQUMsRUFBRCxDQUFSO0FBQ0gsR0FKRDs7QUFNQSxzQkFDSTtBQUFNLFlBQVEsRUFBRUMsVUFBaEI7QUFBQSw0QkFDSTtBQUFPLGlCQUFXLEVBQUMsdUJBQW5CO0FBQTJDLFVBQUksRUFBQyxNQUFoRDtBQUF1RCxXQUFLLEVBQUVGLEtBQTlEO0FBQ0ksY0FBUSxFQUFFRyxDQUFDLElBQUlGLFFBQVEsQ0FBQ0UsQ0FBQyxDQUFDRSxNQUFGLENBQVNMLEtBQVYsQ0FEM0I7QUFFSSxlQUFTLEVBQUM7QUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREosZUFLSTtBQUFRLFVBQUksRUFBQyxRQUFiO0FBQXNCLGVBQVMsRUFBQyxnQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFESjtBQVNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZSxTQUFTTyxJQUFULEdBQWdCO0FBQzdCLFFBQU07QUFBQSxPQUFDcEIsSUFBRDtBQUFBLE9BQU9xQjtBQUFQLE1BQWtCWCwrQ0FBUSxDQUFDO0FBQzdCLFlBQVEsS0FEcUI7QUFFN0IsYUFBUztBQUZvQixHQUFELENBQWhDO0FBS0EsUUFBTTtBQUFBLE9BQUNSLFVBQUQ7QUFBQSxPQUFhb0I7QUFBYixNQUE4QlosK0NBQVEsQ0FBQyxDQUFDLFFBQUQsRUFBVyxXQUFYLENBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ1AsaUJBQUQ7QUFBQSxPQUFvQm9CO0FBQXBCLE1BQXlDYiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdkQ7O0FBRUEsUUFBTWMsWUFBWSxHQUFJQyxLQUFELElBQVc7QUFDOUIsUUFBSUMsYUFBYSxHQUFHLENBQUMsR0FBR3hCLFVBQUosRUFBZ0J1QixLQUFoQixDQUFwQjtBQUNBSCxJQUFBQSxhQUFhLENBQUNJLGFBQUQsQ0FBYjtBQUNBSCxJQUFBQSxpQkFBaUIsQ0FBQyxJQUFELENBQWpCO0FBQ0QsR0FKRDs7QUFNQSxzQkFDRTtBQUFBLHdDQUFlLHVDQUFmO0FBQUEsNEJBQ0UsOERBQUMsa0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQyxjQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBTUU7QUFBQSwwQ0FBZ0IsOENBQWhCO0FBQUEsOEJBQ0UsOERBQUMseURBQUQ7QUFDRSxhQUFLLEVBQUMsZUFEUjtBQUVFLFlBQUksRUFBRXZCLElBRlI7QUFHRSxrQkFBVSxFQUFFRSxVQUhkO0FBSUUseUJBQWlCLEVBQUVDO0FBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQU9FO0FBQUEsNENBQWU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUEYsRUFTSSxDQUFDQSxpQkFBRCxpQkFBc0IsOERBQUMsc0RBQUQ7QUFBTyxvQkFBWSxFQUFFcUI7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVQxQixlQVdFO0FBQUEsNENBQWU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWEYsRUFhSXRCLFVBQVUsQ0FBQ3lCLE1BQVgsR0FBb0IsQ0FBcEIsaUJBQ0EsOERBQUMsd0RBQUQ7QUFBUyxrQkFBVSxFQUFFekI7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBK0JEOzs7Ozs7Ozs7O0FDcEREOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9HcmVldGluZy5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0hpc3RvcnkuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9JbnB1dC5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInN0eWxlZC1qc3gvc3R5bGVcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHcmVldGluZyh7dXNlciwgY29sb3IsIGdyYXRpdHVkZXMsIGhhc1N1Ym1pdHRlZFRvZGF5fSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC02eGxcIj5cclxuICAgICAgICAgICAgPGgxPlxyXG4gICAgICAgICAgICAgICAgSGVsbG8sIDxzcGFuIGNsYXNzTmFtZT17Y29sb3J9Pnt1c2VyLmVtYWlsfTwvc3Bhbj4hXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhhc1N1Ym1pdHRlZFRvZGF5ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWJsYWNrXCI+VG9kYXkgeW91J3JlIGdyYXRlZnVsIGZvciB7Z3JhdGl0dWRlcy5zbGljZSgtMSlbMF19LjwvaDI+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWJsYWNrXCI+V2hhdCBhcmUgeW91IGdyYXRlZnVsIGZvciB0b2RheT88L2gyPlxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApXHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGlzdG9yeSh7IGdyYXRpdHVkZXMgfSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtMnhsXCI+UHJldmlvdXNseSwgeW91IHdlcmUgZ3JhdGVmdWwgZm9yXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPiBcclxuICAgICAgICAgICAgICAgIHtncmF0aXR1ZGVzLm1hcChnID0+ICcgJytnKS50b1N0cmluZygpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgKVxyXG59IiwiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW5wdXQoe2hhbmRsZVN1Ym1pdH0pIHtcclxuICAgIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoXCJcIilcclxuXHJcbiAgICBsZXQgc3VibWl0Rm9ybSA9IGUgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgIGhhbmRsZVN1Ym1pdCh2YWx1ZSlcclxuICAgICAgICBzZXRWYWx1ZShcIlwiKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3N1Ym1pdEZvcm19PlxyXG4gICAgICAgICAgICA8aW5wdXQgcGxhY2Vob2xkZXI9XCJFbnRlciBncmF0aXR1ZGUgaGVyZS5cIiB0eXBlPVwidGV4dFwiIHZhbHVlPXt2YWx1ZX0gXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRWYWx1ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICA8L2lucHV0PlxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJiZy1waW5rLTMwMCByb3VuZGVkIHB4LTEyIHB5LTJcIj5TYXZlPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgKVxyXG59IiwiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IEdyZWV0aW5nIGZyb20gJy4uL2NvbXBvbmVudHMvR3JlZXRpbmcnXG5pbXBvcnQgSGlzdG9yeSBmcm9tICcuLi9jb21wb25lbnRzL0hpc3RvcnknXG5pbXBvcnQgSW5wdXQgZnJvbSAnLi4vY29tcG9uZW50cy9JbnB1dCdcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKHtcbiAgICAgIFwibmFtZVwiOiBcIkJlblwiLFxuICAgICAgXCJlbWFpbFwiOiBcImJrYWhuQGNoYXBtYW4uZWR1XCJcbiAgICB9KVxuXG4gIGNvbnN0IFtncmF0aXR1ZGVzLCBzZXRHcmF0aXR1ZGVzXSA9IHVzZVN0YXRlKFsnaG9ja2V5JywgJ2NvbXB1dGVycyddKVxuICBjb25zdCBbaGFzU3VibWl0dGVkVG9kYXksIHNldFN1Ym1pdHRlZFRvZGF5XSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IGFkZEdyYXRpdHVkZSA9IChlbnRyeSkgPT4ge1xuICAgIGxldCBuZXdHcmF0aXR1ZGVzID0gWy4uLmdyYXRpdHVkZXMsIGVudHJ5XVxuICAgIHNldEdyYXRpdHVkZXMobmV3R3JhdGl0dWRlcylcbiAgICBzZXRTdWJtaXR0ZWRUb2RheSh0cnVlKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNzAwIG1pbi1oLXNjcmVlbiBtaW4tdy1zY3JlZW5cIj5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8dGl0bGU+SGVsbG88L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInJlZCBjb250YWluZXIgbXgtYXV0byBtYXgtdy1wcm9zZSBweC00IHB0LTEyXCI+XG4gICAgICAgIDxHcmVldGluZ1xuICAgICAgICAgIGNvbG9yPVwidGV4dC1waW5rLTMwMFwiXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBncmF0aXR1ZGVzPXtncmF0aXR1ZGVzfVxuICAgICAgICAgIGhhc1N1Ym1pdHRlZFRvZGF5PXtoYXNTdWJtaXR0ZWRUb2RheX1cbiAgICAgICAgPjwvR3JlZXRpbmc+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2VyXCIgLz5cbiAgICAgICAge1xuICAgICAgICAgICFoYXNTdWJtaXR0ZWRUb2RheSAmJiA8SW5wdXQgaGFuZGxlU3VibWl0PXthZGRHcmF0aXR1ZGV9IC8+XG4gICAgICAgIH1cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgZ3JhdGl0dWRlcy5sZW5ndGggPiAwICYmIFxuICAgICAgICAgIDxIaXN0b3J5IGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9IC8+XG4gICAgICAgIH1cbiAgICAgIDwvbWFpbj5cbiAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgLnNwYWNlciB7XG4gICAgICAgICAgaGVpZ2h0OiAyMHB4O1xuICAgICAgICB9XG4gICAgICBgfTwvc3R5bGU+XG4gICAgPC9kaXY+XG4gIClcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWpzeC9zdHlsZVwiKTsiXSwibmFtZXMiOlsiR3JlZXRpbmciLCJ1c2VyIiwiY29sb3IiLCJncmF0aXR1ZGVzIiwiaGFzU3VibWl0dGVkVG9kYXkiLCJlbWFpbCIsInNsaWNlIiwiSGlzdG9yeSIsIm1hcCIsImciLCJ0b1N0cmluZyIsInVzZVN0YXRlIiwiSW5wdXQiLCJoYW5kbGVTdWJtaXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwic3VibWl0Rm9ybSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsIkhlYWQiLCJIb21lIiwic2V0VXNlciIsInNldEdyYXRpdHVkZXMiLCJzZXRTdWJtaXR0ZWRUb2RheSIsImFkZEdyYXRpdHVkZSIsImVudHJ5IiwibmV3R3JhdGl0dWRlcyIsImxlbmd0aCJdLCJzb3VyY2VSb290IjoiIn0=