"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Greeting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Greeting */ "./components/Greeting.js");
/* harmony import */ var _components_History__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/History */ "./components/History.js");
/* harmony import */ var _components_Input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Input */ "./components/Input.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\pages\\index.js",
    _s = $RefreshSig$();








function Home() {
  _s();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
    "name": "Ben",
    "email": "bkahn@chapman.edu"
  }),
      user = _useState[0],
      setUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(['hockey', 'computers']),
      gratitudes = _useState2[0],
      setGratitudes = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      hasSubmittedToday = _useState3[0],
      setSubmittedToday = _useState3[1];

  var addGratitude = function addGratitude(entry) {
    var newGratitudes = [].concat((0,C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(gratitudes), [entry]);
    setGratitudes(newGratitudes);
    setSubmittedToday(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
    className: "jsx-3938730314" + " " + "bg-blue-900 min-h-screen min-w-screen",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("title", {
        className: "jsx-3938730314",
        children: "Hello"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico",
        className: "jsx-3938730314"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("main", {
      className: "jsx-3938730314" + " " + "red container mx-auto max-w-prose px-4 pt-12 font-serif",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_Greeting__WEBPACK_IMPORTED_MODULE_3__.default, {
        color: "text-green-400",
        user: user,
        gratitudes: gratitudes,
        hasSubmittedToday: hasSubmittedToday
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this), !hasSubmittedToday && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_Input__WEBPACK_IMPORTED_MODULE_5__.default, {
        handleSubmit: addGratitude
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 33
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, this), gratitudes.length > 0 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_History__WEBPACK_IMPORTED_MODULE_4__.default, {
        gratitudes: gratitudes
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
      id: "3938730314",
      children: ".spacer.jsx-3938730314{height:20px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBNkNrQixBQUd1QixZQUNkIiwiZmlsZSI6IkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoWydob2NrZXknLCAnY29tcHV0ZXJzJ10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS05MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVkIGNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTIgZm9udC1zZXJpZlwiPlxuICAgICAgICA8R3JlZXRpbmdcbiAgICAgICAgICBjb2xvcj1cInRleHQtZ3JlZW4tNDAwXCJcbiAgICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICAgIGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9XG4gICAgICAgICAgaGFzU3VibWl0dGVkVG9kYXk9e2hhc1N1Ym1pdHRlZFRvZGF5fVxuICAgICAgICA+PC9HcmVldGluZz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgIWhhc1N1Ym1pdHRlZFRvZGF5ICYmIDxJbnB1dCBoYW5kbGVTdWJtaXQ9e2FkZEdyYXRpdHVkZX0gLz5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlclwiIC8+XG4gICAgICAgIHtcbiAgICAgICAgICBncmF0aXR1ZGVzLmxlbmd0aCA+IDAgJiYgXG4gICAgICAgICAgPEhpc3RvcnkgZ3JhdGl0dWRlcz17Z3JhdGl0dWRlc30gLz5cbiAgICAgICAgfVxuICAgICAgPC9tYWluPlxuICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAuc3BhY2VyIHtcbiAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgIH1cbiAgICAgIGB9PC9zdHlsZT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Benjamin\\\\Desktop\\\\CPSC458\\\\gratitude-journal\\\\pages\\\\index.js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

_s(Home, "7G02DU0v3IKaZnzlTPYTl7oD4Yk=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZDc1ZTZkZWU3OWQ2ZmI3OTdkNjIuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUsU0FBU0ssSUFBVCxHQUFnQjtBQUFBOztBQUM3QixrQkFBd0JELCtDQUFRLENBQUM7QUFDN0IsWUFBUSxLQURxQjtBQUU3QixhQUFTO0FBRm9CLEdBQUQsQ0FBaEM7QUFBQSxNQUFPRSxJQUFQO0FBQUEsTUFBYUMsT0FBYjs7QUFLQSxtQkFBb0NILCtDQUFRLENBQUMsQ0FBQyxRQUFELEVBQVcsV0FBWCxDQUFELENBQTVDO0FBQUEsTUFBT0ksVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxtQkFBK0NMLCtDQUFRLENBQUMsS0FBRCxDQUF2RDtBQUFBLE1BQU9NLGlCQUFQO0FBQUEsTUFBMEJDLGlCQUExQjs7QUFFQSxNQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxLQUFELEVBQVc7QUFDOUIsUUFBSUMsYUFBYSxrS0FBT04sVUFBUCxJQUFtQkssS0FBbkIsRUFBakI7QUFDQUosSUFBQUEsYUFBYSxDQUFDSyxhQUFELENBQWI7QUFDQUgsSUFBQUEsaUJBQWlCLENBQUMsSUFBRCxDQUFqQjtBQUNELEdBSkQ7O0FBTUEsc0JBQ0U7QUFBQSx3Q0FBZSx1Q0FBZjtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUMsY0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQU1FO0FBQUEsMENBQWdCLHlEQUFoQjtBQUFBLDhCQUNFLDhEQUFDLHlEQUFEO0FBQ0UsYUFBSyxFQUFDLGdCQURSO0FBRUUsWUFBSSxFQUFFTCxJQUZSO0FBR0Usa0JBQVUsRUFBRUUsVUFIZDtBQUlFLHlCQUFpQixFQUFFRTtBQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFPRTtBQUFBLDRDQUFlO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVBGLEVBU0ksQ0FBQ0EsaUJBQUQsaUJBQXNCLDhEQUFDLHNEQUFEO0FBQU8sb0JBQVksRUFBRUU7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVQxQixlQVdFO0FBQUEsNENBQWU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWEYsRUFhSUosVUFBVSxDQUFDTyxNQUFYLEdBQW9CLENBQXBCLGlCQUNBLDhEQUFDLHdEQUFEO0FBQVMsa0JBQVUsRUFBRVA7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBK0JEOztHQTlDdUJIOztLQUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoWydob2NrZXknLCAnY29tcHV0ZXJzJ10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS05MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVkIGNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTIgZm9udC1zZXJpZlwiPlxuICAgICAgICA8R3JlZXRpbmdcbiAgICAgICAgICBjb2xvcj1cInRleHQtZ3JlZW4tNDAwXCJcbiAgICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICAgIGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9XG4gICAgICAgICAgaGFzU3VibWl0dGVkVG9kYXk9e2hhc1N1Ym1pdHRlZFRvZGF5fVxuICAgICAgICA+PC9HcmVldGluZz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgIWhhc1N1Ym1pdHRlZFRvZGF5ICYmIDxJbnB1dCBoYW5kbGVTdWJtaXQ9e2FkZEdyYXRpdHVkZX0gLz5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlclwiIC8+XG4gICAgICAgIHtcbiAgICAgICAgICBncmF0aXR1ZGVzLmxlbmd0aCA+IDAgJiYgXG4gICAgICAgICAgPEhpc3RvcnkgZ3JhdGl0dWRlcz17Z3JhdGl0dWRlc30gLz5cbiAgICAgICAgfVxuICAgICAgPC9tYWluPlxuICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAuc3BhY2VyIHtcbiAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgIH1cbiAgICAgIGB9PC9zdHlsZT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sIm5hbWVzIjpbIkhlYWQiLCJHcmVldGluZyIsIkhpc3RvcnkiLCJJbnB1dCIsInVzZVN0YXRlIiwiSG9tZSIsInVzZXIiLCJzZXRVc2VyIiwiZ3JhdGl0dWRlcyIsInNldEdyYXRpdHVkZXMiLCJoYXNTdWJtaXR0ZWRUb2RheSIsInNldFN1Ym1pdHRlZFRvZGF5IiwiYWRkR3JhdGl0dWRlIiwiZW50cnkiLCJuZXdHcmF0aXR1ZGVzIiwibGVuZ3RoIl0sInNvdXJjZVJvb3QiOiIifQ==