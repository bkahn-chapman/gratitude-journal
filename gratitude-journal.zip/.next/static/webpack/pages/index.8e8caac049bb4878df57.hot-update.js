"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Greeting__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Greeting */ "./components/Greeting.js");
/* harmony import */ var _components_History__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/History */ "./components/History.js");
/* harmony import */ var _components_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Input */ "./components/Input.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\pages\\index.js",
    _s = $RefreshSig$();







function Home() {
  _s();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
    "name": "Ben",
    "email": "bkahn@chapman.edu"
  }),
      user = _useState[0],
      setUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(['test', 'test1']),
      gratitudes = _useState2[0],
      setGratitudes = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false),
      hasSubmittedToday = _useState3[0],
      setSubmittedToday = _useState3[1];

  var addGratitude = function addGratitude(entry) {
    var newGratitudes = [].concat((0,C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(gratitudes), [entry]);
    setGratitudes(newGratitudes);
    setSubmittedToday(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
    className: "bg-gray-700 min-h-screen min-w-screen",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("title", {
        children: "Hello"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("main", {
      className: "container mx-auto max-w-prose px-4 pt-12",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Greeting__WEBPACK_IMPORTED_MODULE_2__.default, {
        color: "text-pink-300",
        user: user,
        gratitudes: gratitudes,
        hasSubmittedToday: hasSubmittedToday
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), !hasSubmittedToday && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Input__WEBPACK_IMPORTED_MODULE_4__.default, {
        handleSubmit: addGratitude
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 33
      }, this), gratitudes.length > 0 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_History__WEBPACK_IMPORTED_MODULE_3__.default, {
        gratitudes: gratitudes
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

_s(Home, "Ta2xKOqxxMN6uRMZkvK49YYX56c=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguOGU4Y2FhYzA0OWJiNDg3OGRmNTcuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUsU0FBU0ssSUFBVCxHQUFnQjtBQUFBOztBQUM3QixrQkFBd0JELCtDQUFRLENBQUM7QUFDN0IsWUFBUSxLQURxQjtBQUU3QixhQUFTO0FBRm9CLEdBQUQsQ0FBaEM7QUFBQSxNQUFPRSxJQUFQO0FBQUEsTUFBYUMsT0FBYjs7QUFLQSxtQkFBb0NILCtDQUFRLENBQUMsQ0FBQyxNQUFELEVBQVMsT0FBVCxDQUFELENBQTVDO0FBQUEsTUFBT0ksVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxtQkFBK0NMLCtDQUFRLENBQUMsS0FBRCxDQUF2RDtBQUFBLE1BQU9NLGlCQUFQO0FBQUEsTUFBMEJDLGlCQUExQjs7QUFFQSxNQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxLQUFELEVBQVc7QUFDOUIsUUFBSUMsYUFBYSxrS0FBT04sVUFBUCxJQUFtQkssS0FBbkIsRUFBakI7QUFDQUosSUFBQUEsYUFBYSxDQUFDSyxhQUFELENBQWI7QUFDQUgsSUFBQUEsaUJBQWlCLENBQUMsSUFBRCxDQUFqQjtBQUNELEdBSkQ7O0FBTUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsdUNBQWY7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFNRTtBQUFNLGVBQVMsRUFBQywwQ0FBaEI7QUFBQSw4QkFDRSw4REFBQyx5REFBRDtBQUNFLGFBQUssRUFBQyxlQURSO0FBRUUsWUFBSSxFQUFFTCxJQUZSO0FBR0Usa0JBQVUsRUFBRUUsVUFIZDtBQUlFLHlCQUFpQixFQUFFRTtBQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsRUFRSSxDQUFDQSxpQkFBRCxpQkFBc0IsOERBQUMsc0RBQUQ7QUFBTyxvQkFBWSxFQUFFRTtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUjFCLEVBV0lKLFVBQVUsQ0FBQ08sTUFBWCxHQUFvQixDQUFwQixpQkFDQSw4REFBQyx3REFBRDtBQUFTLGtCQUFVLEVBQUVQO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXdCRDs7R0F2Q3VCSDs7S0FBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IEdyZWV0aW5nIGZyb20gJy4uL2NvbXBvbmVudHMvR3JlZXRpbmcnXG5pbXBvcnQgSGlzdG9yeSBmcm9tICcuLi9jb21wb25lbnRzL0hpc3RvcnknXG5pbXBvcnQgSW5wdXQgZnJvbSAnLi4vY29tcG9uZW50cy9JbnB1dCdcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKHtcbiAgICAgIFwibmFtZVwiOiBcIkJlblwiLFxuICAgICAgXCJlbWFpbFwiOiBcImJrYWhuQGNoYXBtYW4uZWR1XCJcbiAgICB9KVxuXG4gIGNvbnN0IFtncmF0aXR1ZGVzLCBzZXRHcmF0aXR1ZGVzXSA9IHVzZVN0YXRlKFsndGVzdCcsICd0ZXN0MSddKVxuICBjb25zdCBbaGFzU3VibWl0dGVkVG9kYXksIHNldFN1Ym1pdHRlZFRvZGF5XSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IGFkZEdyYXRpdHVkZSA9IChlbnRyeSkgPT4ge1xuICAgIGxldCBuZXdHcmF0aXR1ZGVzID0gWy4uLmdyYXRpdHVkZXMsIGVudHJ5XVxuICAgIHNldEdyYXRpdHVkZXMobmV3R3JhdGl0dWRlcylcbiAgICBzZXRTdWJtaXR0ZWRUb2RheSh0cnVlKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNzAwIG1pbi1oLXNjcmVlbiBtaW4tdy1zY3JlZW5cIj5cbiAgICAgIDxIZWFkPlxuICAgICAgICA8dGl0bGU+SGVsbG88L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTJcIj5cbiAgICAgICAgPEdyZWV0aW5nXG4gICAgICAgICAgY29sb3I9XCJ0ZXh0LXBpbmstMzAwXCJcbiAgICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICAgIGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9XG4gICAgICAgICAgaGFzU3VibWl0dGVkVG9kYXk9e2hhc1N1Ym1pdHRlZFRvZGF5fVxuICAgICAgICA+PC9HcmVldGluZz5cbiAgICAgICAge1xuICAgICAgICAgICFoYXNTdWJtaXR0ZWRUb2RheSAmJiA8SW5wdXQgaGFuZGxlU3VibWl0PXthZGRHcmF0aXR1ZGV9IC8+XG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIGdyYXRpdHVkZXMubGVuZ3RoID4gMCAmJiBcbiAgICAgICAgICA8SGlzdG9yeSBncmF0aXR1ZGVzPXtncmF0aXR1ZGVzfSAvPlxuICAgICAgICB9XG4gICAgICA8L21haW4+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJIZWFkIiwiR3JlZXRpbmciLCJIaXN0b3J5IiwiSW5wdXQiLCJ1c2VTdGF0ZSIsIkhvbWUiLCJ1c2VyIiwic2V0VXNlciIsImdyYXRpdHVkZXMiLCJzZXRHcmF0aXR1ZGVzIiwiaGFzU3VibWl0dGVkVG9kYXkiLCJzZXRTdWJtaXR0ZWRUb2RheSIsImFkZEdyYXRpdHVkZSIsImVudHJ5IiwibmV3R3JhdGl0dWRlcyIsImxlbmd0aCJdLCJzb3VyY2VSb290IjoiIn0=