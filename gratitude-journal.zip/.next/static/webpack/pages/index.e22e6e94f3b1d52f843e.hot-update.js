"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Greeting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Greeting */ "./components/Greeting.js");
/* harmony import */ var _components_History__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/History */ "./components/History.js");
/* harmony import */ var _components_Input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Input */ "./components/Input.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\pages\\index.js",
    _s = $RefreshSig$();








function Home() {
  _s();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
    "name": "Ben",
    "email": "bkahn@chapman.edu"
  }),
      user = _useState[0],
      setUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(['hockey', 'computers']),
      gratitudes = _useState2[0],
      setGratitudes = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      hasSubmittedToday = _useState3[0],
      setSubmittedToday = _useState3[1];

  var addGratitude = function addGratitude(entry) {
    var newGratitudes = [].concat((0,C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(gratitudes), [entry]);
    setGratitudes(newGratitudes);
    setSubmittedToday(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
    className: "jsx-3938730314" + " " + "bg-gray-700 min-h-screen min-w-screen",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("title", {
        className: "jsx-3938730314",
        children: "Hello"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico",
        className: "jsx-3938730314"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("main", {
      className: "jsx-3938730314" + " " + "red container mx-auto max-w-prose px-4 pt-12",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_Greeting__WEBPACK_IMPORTED_MODULE_3__.default, {
        color: "text-pink-300",
        user: user,
        gratitudes: gratitudes,
        hasSubmittedToday: hasSubmittedToday
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this), !hasSubmittedToday && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_Input__WEBPACK_IMPORTED_MODULE_5__.default, {
        handleSubmit: addGratitude
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 33
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "jsx-3938730314" + " " + "spacer"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, this), gratitudes.length > 0 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_History__WEBPACK_IMPORTED_MODULE_4__.default, {
        gratitudes: gratitudes
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
      id: "3938730314",
      children: ".spacer.jsx-3938730314{height:20px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBNkNrQixBQUd1QixZQUNkIiwiZmlsZSI6IkM6XFxVc2Vyc1xcQmVuamFtaW5cXERlc2t0b3BcXENQU0M0NThcXGdyYXRpdHVkZS1qb3VybmFsXFxwYWdlc1xcaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoWydob2NrZXknLCAnY29tcHV0ZXJzJ10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS03MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVkIGNvbnRhaW5lciBteC1hdXRvIG1heC13LXByb3NlIHB4LTQgcHQtMTJcIj5cbiAgICAgICAgPEdyZWV0aW5nXG4gICAgICAgICAgY29sb3I9XCJ0ZXh0LXBpbmstMzAwXCJcbiAgICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICAgIGdyYXRpdHVkZXM9e2dyYXRpdHVkZXN9XG4gICAgICAgICAgaGFzU3VibWl0dGVkVG9kYXk9e2hhc1N1Ym1pdHRlZFRvZGF5fVxuICAgICAgICA+PC9HcmVldGluZz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZXJcIiAvPlxuICAgICAgICB7XG4gICAgICAgICAgIWhhc1N1Ym1pdHRlZFRvZGF5ICYmIDxJbnB1dCBoYW5kbGVTdWJtaXQ9e2FkZEdyYXRpdHVkZX0gLz5cbiAgICAgICAgfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlclwiIC8+XG4gICAgICAgIHtcbiAgICAgICAgICBncmF0aXR1ZGVzLmxlbmd0aCA+IDAgJiYgXG4gICAgICAgICAgPEhpc3RvcnkgZ3JhdGl0dWRlcz17Z3JhdGl0dWRlc30gLz5cbiAgICAgICAgfVxuICAgICAgPC9tYWluPlxuICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAuc3BhY2VyIHtcbiAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgIH1cbiAgICAgIGB9PC9zdHlsZT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Benjamin\\\\Desktop\\\\CPSC458\\\\gratitude-journal\\\\pages\\\\index.js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

_s(Home, "7G02DU0v3IKaZnzlTPYTl7oD4Yk=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZTIyZTZlOTRmM2IxZDUyZjg0M2UuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUsU0FBU0ssSUFBVCxHQUFnQjtBQUFBOztBQUM3QixrQkFBd0JELCtDQUFRLENBQUM7QUFDN0IsWUFBUSxLQURxQjtBQUU3QixhQUFTO0FBRm9CLEdBQUQsQ0FBaEM7QUFBQSxNQUFPRSxJQUFQO0FBQUEsTUFBYUMsT0FBYjs7QUFLQSxtQkFBb0NILCtDQUFRLENBQUMsQ0FBQyxRQUFELEVBQVcsV0FBWCxDQUFELENBQTVDO0FBQUEsTUFBT0ksVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxtQkFBK0NMLCtDQUFRLENBQUMsS0FBRCxDQUF2RDtBQUFBLE1BQU9NLGlCQUFQO0FBQUEsTUFBMEJDLGlCQUExQjs7QUFFQSxNQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDQyxLQUFELEVBQVc7QUFDOUIsUUFBSUMsYUFBYSxrS0FBT04sVUFBUCxJQUFtQkssS0FBbkIsRUFBakI7QUFDQUosSUFBQUEsYUFBYSxDQUFDSyxhQUFELENBQWI7QUFDQUgsSUFBQUEsaUJBQWlCLENBQUMsSUFBRCxDQUFqQjtBQUNELEdBSkQ7O0FBTUEsc0JBQ0U7QUFBQSx3Q0FBZSx1Q0FBZjtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUMsY0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQU1FO0FBQUEsMENBQWdCLDhDQUFoQjtBQUFBLDhCQUNFLDhEQUFDLHlEQUFEO0FBQ0UsYUFBSyxFQUFDLGVBRFI7QUFFRSxZQUFJLEVBQUVMLElBRlI7QUFHRSxrQkFBVSxFQUFFRSxVQUhkO0FBSUUseUJBQWlCLEVBQUVFO0FBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQU9FO0FBQUEsNENBQWU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUEYsRUFTSSxDQUFDQSxpQkFBRCxpQkFBc0IsOERBQUMsc0RBQUQ7QUFBTyxvQkFBWSxFQUFFRTtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVDFCLGVBV0U7QUFBQSw0Q0FBZTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FYRixFQWFJSixVQUFVLENBQUNPLE1BQVgsR0FBb0IsQ0FBcEIsaUJBQ0EsOERBQUMsd0RBQUQ7QUFBUyxrQkFBVSxFQUFFUDtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUErQkQ7O0dBOUN1Qkg7O0tBQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcbmltcG9ydCBHcmVldGluZyBmcm9tICcuLi9jb21wb25lbnRzL0dyZWV0aW5nJ1xuaW1wb3J0IEhpc3RvcnkgZnJvbSAnLi4vY29tcG9uZW50cy9IaXN0b3J5J1xuaW1wb3J0IElucHV0IGZyb20gJy4uL2NvbXBvbmVudHMvSW5wdXQnXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZSh7XG4gICAgICBcIm5hbWVcIjogXCJCZW5cIixcbiAgICAgIFwiZW1haWxcIjogXCJia2FobkBjaGFwbWFuLmVkdVwiXG4gICAgfSlcblxuICBjb25zdCBbZ3JhdGl0dWRlcywgc2V0R3JhdGl0dWRlc10gPSB1c2VTdGF0ZShbJ2hvY2tleScsICdjb21wdXRlcnMnXSlcbiAgY29uc3QgW2hhc1N1Ym1pdHRlZFRvZGF5LCBzZXRTdWJtaXR0ZWRUb2RheV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBhZGRHcmF0aXR1ZGUgPSAoZW50cnkpID0+IHtcbiAgICBsZXQgbmV3R3JhdGl0dWRlcyA9IFsuLi5ncmF0aXR1ZGVzLCBlbnRyeV1cbiAgICBzZXRHcmF0aXR1ZGVzKG5ld0dyYXRpdHVkZXMpXG4gICAgc2V0U3VibWl0dGVkVG9kYXkodHJ1ZSlcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTcwMCBtaW4taC1zY3JlZW4gbWluLXctc2NyZWVuXCI+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkhlbGxvPC90aXRsZT5cbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxuICAgICAgPC9IZWFkPlxuXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJyZWQgY29udGFpbmVyIG14LWF1dG8gbWF4LXctcHJvc2UgcHgtNCBwdC0xMlwiPlxuICAgICAgICA8R3JlZXRpbmdcbiAgICAgICAgICBjb2xvcj1cInRleHQtcGluay0zMDBcIlxuICAgICAgICAgIHVzZXI9e3VzZXJ9XG4gICAgICAgICAgZ3JhdGl0dWRlcz17Z3JhdGl0dWRlc31cbiAgICAgICAgICBoYXNTdWJtaXR0ZWRUb2RheT17aGFzU3VibWl0dGVkVG9kYXl9XG4gICAgICAgID48L0dyZWV0aW5nPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlclwiIC8+XG4gICAgICAgIHtcbiAgICAgICAgICAhaGFzU3VibWl0dGVkVG9kYXkgJiYgPElucHV0IGhhbmRsZVN1Ym1pdD17YWRkR3JhdGl0dWRlfSAvPlxuICAgICAgICB9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2VyXCIgLz5cbiAgICAgICAge1xuICAgICAgICAgIGdyYXRpdHVkZXMubGVuZ3RoID4gMCAmJiBcbiAgICAgICAgICA8SGlzdG9yeSBncmF0aXR1ZGVzPXtncmF0aXR1ZGVzfSAvPlxuICAgICAgICB9XG4gICAgICA8L21haW4+XG4gICAgICA8c3R5bGUganN4PntgXG4gICAgICAgIC5zcGFjZXIge1xuICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgfVxuICAgICAgYH08L3N0eWxlPlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwibmFtZXMiOlsiSGVhZCIsIkdyZWV0aW5nIiwiSGlzdG9yeSIsIklucHV0IiwidXNlU3RhdGUiLCJIb21lIiwidXNlciIsInNldFVzZXIiLCJncmF0aXR1ZGVzIiwic2V0R3JhdGl0dWRlcyIsImhhc1N1Ym1pdHRlZFRvZGF5Iiwic2V0U3VibWl0dGVkVG9kYXkiLCJhZGRHcmF0aXR1ZGUiLCJlbnRyeSIsIm5ld0dyYXRpdHVkZXMiLCJsZW5ndGgiXSwic291cmNlUm9vdCI6IiJ9