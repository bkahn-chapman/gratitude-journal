"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Greeting__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Greeting */ "./components/Greeting.js");
/* harmony import */ var _components_History__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/History */ "./components/History.js");
/* harmony import */ var _components_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Input */ "./components/Input.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\Benjamin\\Desktop\\CPSC458\\gratitude-journal\\pages\\index.js",
    _s = $RefreshSig$();







function Home() {
  _s();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
    "name": "Ben",
    "email": "bkahn@chapman.edu"
  }),
      user = _useState[0],
      setUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]),
      gratitudes = _useState2[0],
      setGratitudes = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false),
      hasSubmittedToday = _useState3[0],
      setSubmittedToday = _useState3[1];

  var addGratitude = function addGratitude(entry) {
    var newGratitudes = [].concat((0,C_Users_Benjamin_Desktop_CPSC458_gratitude_journal_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__.default)(gratitudes), [entry]);
    setGratitudes(newGratitudes);
    setSubmittedToday(true);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
    className: "bg-gray-700 min-h-screen min-w-screen",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("title", {
        children: "Hello"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("main", {
      className: "container mx-auto max-w-prose px-4 pt-12",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Greeting__WEBPACK_IMPORTED_MODULE_2__.default, {
        color: "text-pink-300",
        user: user,
        gratitudes: gratitudes,
        hasSubmittedToday: hasSubmittedToday
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_Input__WEBPACK_IMPORTED_MODULE_4__.default, {
        handleSubmit: addGratitude
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this), gratitudes.length > 0 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_History__WEBPACK_IMPORTED_MODULE_3__.default, {
        gratitudes: gratitudes
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

_s(Home, "lKZS1wRY6yTSmZXG1eGMzAKy8TA=");

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMGNjZjZkOGY1ZDA2OGIwNDFiZjUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUsU0FBU0ssSUFBVCxHQUFnQjtBQUFBOztBQUM3QixrQkFBd0JELCtDQUFRLENBQUM7QUFDN0IsWUFBUSxLQURxQjtBQUU3QixhQUFTO0FBRm9CLEdBQUQsQ0FBaEM7QUFBQSxNQUFPRSxJQUFQO0FBQUEsTUFBYUMsT0FBYjs7QUFLQSxtQkFBb0NILCtDQUFRLENBQUMsRUFBRCxDQUE1QztBQUFBLE1BQU9JLFVBQVA7QUFBQSxNQUFtQkMsYUFBbkI7O0FBQ0EsbUJBQStDTCwrQ0FBUSxDQUFDLEtBQUQsQ0FBdkQ7QUFBQSxNQUFPTSxpQkFBUDtBQUFBLE1BQTBCQyxpQkFBMUI7O0FBRUEsTUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ0MsS0FBRCxFQUFXO0FBQzlCLFFBQUlDLGFBQWEsa0tBQU9OLFVBQVAsSUFBbUJLLEtBQW5CLEVBQWpCO0FBQ0FKLElBQUFBLGFBQWEsQ0FBQ0ssYUFBRCxDQUFiO0FBQ0FILElBQUFBLGlCQUFpQixDQUFDLElBQUQsQ0FBakI7QUFDRCxHQUpEOztBQU1BLHNCQUNFO0FBQUssYUFBUyxFQUFDLHVDQUFmO0FBQUEsNEJBQ0UsOERBQUMsa0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBTUU7QUFBTSxlQUFTLEVBQUMsMENBQWhCO0FBQUEsOEJBQ0UsOERBQUMseURBQUQ7QUFDRSxhQUFLLEVBQUMsZUFEUjtBQUVFLFlBQUksRUFBRUwsSUFGUjtBQUdFLGtCQUFVLEVBQUVFLFVBSGQ7QUFJRSx5QkFBaUIsRUFBRUU7QUFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBT0UsOERBQUMsc0RBQUQ7QUFBTyxvQkFBWSxFQUFFRTtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUEYsRUFTSUosVUFBVSxDQUFDTyxNQUFYLEdBQW9CLENBQXBCLGlCQUNBLDhEQUFDLHdEQUFEO0FBQVMsa0JBQVUsRUFBRVA7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBc0JEOztHQXJDdUJIOztLQUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgR3JlZXRpbmcgZnJvbSAnLi4vY29tcG9uZW50cy9HcmVldGluZydcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4uL2NvbXBvbmVudHMvSGlzdG9yeSdcbmltcG9ydCBJbnB1dCBmcm9tICcuLi9jb21wb25lbnRzL0lucHV0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoe1xuICAgICAgXCJuYW1lXCI6IFwiQmVuXCIsXG4gICAgICBcImVtYWlsXCI6IFwiYmthaG5AY2hhcG1hbi5lZHVcIlxuICAgIH0pXG5cbiAgY29uc3QgW2dyYXRpdHVkZXMsIHNldEdyYXRpdHVkZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtoYXNTdWJtaXR0ZWRUb2RheSwgc2V0U3VibWl0dGVkVG9kYXldID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgYWRkR3JhdGl0dWRlID0gKGVudHJ5KSA9PiB7XG4gICAgbGV0IG5ld0dyYXRpdHVkZXMgPSBbLi4uZ3JhdGl0dWRlcywgZW50cnldXG4gICAgc2V0R3JhdGl0dWRlcyhuZXdHcmF0aXR1ZGVzKVxuICAgIHNldFN1Ym1pdHRlZFRvZGF5KHRydWUpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS03MDAgbWluLWgtc2NyZWVuIG1pbi13LXNjcmVlblwiPlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5IZWxsbzwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cblxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiY29udGFpbmVyIG14LWF1dG8gbWF4LXctcHJvc2UgcHgtNCBwdC0xMlwiPlxuICAgICAgICA8R3JlZXRpbmdcbiAgICAgICAgICBjb2xvcj1cInRleHQtcGluay0zMDBcIlxuICAgICAgICAgIHVzZXI9e3VzZXJ9XG4gICAgICAgICAgZ3JhdGl0dWRlcz17Z3JhdGl0dWRlc31cbiAgICAgICAgICBoYXNTdWJtaXR0ZWRUb2RheT17aGFzU3VibWl0dGVkVG9kYXl9XG4gICAgICAgID48L0dyZWV0aW5nPlxuICAgICAgICA8SW5wdXQgaGFuZGxlU3VibWl0PXthZGRHcmF0aXR1ZGV9Lz5cbiAgICAgICAge1xuICAgICAgICAgIGdyYXRpdHVkZXMubGVuZ3RoID4gMCAmJiBcbiAgICAgICAgICA8SGlzdG9yeSBncmF0aXR1ZGVzPXtncmF0aXR1ZGVzfSAvPlxuICAgICAgICB9XG4gICAgICA8L21haW4+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJIZWFkIiwiR3JlZXRpbmciLCJIaXN0b3J5IiwiSW5wdXQiLCJ1c2VTdGF0ZSIsIkhvbWUiLCJ1c2VyIiwic2V0VXNlciIsImdyYXRpdHVkZXMiLCJzZXRHcmF0aXR1ZGVzIiwiaGFzU3VibWl0dGVkVG9kYXkiLCJzZXRTdWJtaXR0ZWRUb2RheSIsImFkZEdyYXRpdHVkZSIsImVudHJ5IiwibmV3R3JhdGl0dWRlcyIsImxlbmd0aCJdLCJzb3VyY2VSb290IjoiIn0=